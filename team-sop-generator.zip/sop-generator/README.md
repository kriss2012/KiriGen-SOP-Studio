# Team SOP Generator

Turn messy process notes — Loom transcripts, Slack threads, voice memo
transcripts, stream-of-consciousness rambling — into a clean, structured
document your team can actually use: an SOP, an onboarding guide, a
checklist, or a QA system.

This is a single, self-contained web page. There's no server, no install,
no build step. It calls the Anthropic API directly from your browser using
your own API key.

## Quick start

1. Unzip this folder.
2. Double-click `index.html` (or open it in any modern browser — Chrome,
   Safari, Firefox, Edge).
3. Open **⚙ API settings** and paste in your Anthropic API key.
   - Don't have one? Get it at https://console.anthropic.com/settings/keys
   - Check "Remember key on this device" if you want it saved in your
     browser for next time (stored only in your browser's local storage —
     never sent anywhere except to `api.anthropic.com`).
4. Pick an output type: **SOP**, **Onboarding Doc**, **Checklist**, or
   **QA System**.
5. Paste your messy transcript or notes into the "Raw material" box
   (or click "Attach a .txt/.md file" to upload one instead).
6. Optionally fill in the process name and who runs the process — this
   helps the model write a more specific, less generic document.
7. Click **Generate document**.

Your finished document appears on the right, formatted like a real
operating document with a document-control header and numbered steps.
From there you can:

- **Copy** the raw Markdown to paste into Notion, Google Docs, Confluence, etc.
- **Download .md** to save it as a Markdown file.
- **Print / PDF** to save a clean, printable PDF version.
- **Regenerate** to run it again (useful if you tweak the detail level or
  process name and want a fresh version).

Every document you generate in a session is kept in the tab strip below
the document so you can flip between multiple SOPs without losing your
work.

## The four document types

| Type | Best for |
|---|---|
| **SOP** | A formal, numbered procedure with a purpose statement, tools needed, and a "definition of done." |
| **Onboarding Doc** | The same process, written for a first-timer — explains *why*, not just *what*. |
| **Checklist** | A tight, scannable list of checkboxes, grouped into phases if relevant. Good for printing and taping to a wall. |
| **QA System** | Turns the process into pass/fail checkpoints, escalation steps, and a review cadence. |

You can also control the **detail level** (concise / standard / thorough)
to match how much hand-holding your team needs.

## Notes on the API key

This tool is meant for **personal or internal team use** — it's a
"bring your own key" tool, the same pattern used by many lightweight
internal utilities. Your key is used only to call
`https://api.anthropic.com/v1/messages` directly from your browser; it is
never sent to any other server, and this project has no backend at all.

Because the key lives in the page, don't host this on a public website
or share a version of it that has your key saved in "remember." If you
want to share the *tool* with teammates, share the unzipped folder (or
this repo) and have each person add their own key.

## Customizing

Everything lives in `index.html` — HTML, CSS, and JavaScript in one file,
no build tools required. A few easy things to tweak:

- **Model**: change the default in the "Model" field under API settings
  (defaults to `claude-sonnet-4-6`).
- **Prompts**: the instructions for each document type live in the
  `TYPE_INSTRUCTIONS` object in the `<script>` at the bottom of the file —
  edit these to change tone, structure, or required sections.
- **Look**: colors and fonts are defined as CSS variables at the very top
  of the `<style>` block (`--paper`, `--ink`, `--blueprint`, `--stamp`,
  `--manila`).

## Troubleshooting

- **"Add your Anthropic API key..."** — you need a key from
  console.anthropic.com; the free Claude.ai chat app does not work here.
- **401 / authentication error** — double check the key was copied in
  full (it starts with `sk-ant-`) and that it's active in your console.
- **"Could not reach the Anthropic API"** — check your internet
  connection; some corporate networks block direct API calls.
